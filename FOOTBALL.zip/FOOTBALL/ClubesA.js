const clubes = [
    {
        nombre:'Argentinos Juniors'
    },
    {
        nombre:'Atletico Tucuman'
    },
    {
        nombre:'Banfield'
    },
    {
        nombre:'Barracas Central'
    },
    {
        nombre:'Belgrano'
    },
    {
        nombre:'Boca Junior'
    },
    {
        nombre:'Central Cordoba'
    },
    {
        nombre:'Defensa y Justicia'
    },
    {
        nombre:'Deportivo Riestra'
    },
    {
        nombre:'Estudiantes de La Plata'
    },
    {
        nombre:'Gimnasia y Esgrima de La Plata'
    },
    {
        nombre:'Godoy Cruz de Mendoza'
    },
    {
        nombre:'Huracan'
    },
    {
        nombre:'Independiente'
    },
    {
        nombre:'Independiente Rivadavia de Mendoza'
    },
    {
        nombre:'Instituto de Cordoba'
    },
    {
        nombre:'Lanus'
    },
    {
        nombre:'Newells Old Boys'
    },
    {
        nombre:'Platense'
    },
    {
        nombre:'Racing Club'
    },
    {
        nombre:'River Plate'
    },
    {
        nombre:'Rosario Central'
    },
    {
        nombre:'San Lorenzo'
    },
    {
        nombre:'Sarmiento de Junin'
    },
    {
        nombre:'Talleres de Cordoba'
    },
    {
        nombre:'Tigre'
    },
    {
        nombre:'Union de Santa Fe'
    },
    {
        nombre:'Velez Sarfield'
    },
]